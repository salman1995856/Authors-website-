import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function BlogPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="flex flex-col items-center justify-center space-y-4 text-center">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Blog</h1>
          <p className="max-w-[700px] text-muted-foreground md:text-xl">Thoughts on writing, publishing, and life</p>
        </div>
      </div>

      <div className="grid gap-8 mt-12">
        {blogPosts.map((post, index) => (
          <Card key={index} className="overflow-hidden">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="relative h-64 md:h-full">
                <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
              </div>
              <CardContent className="p-6 flex flex-col justify-between">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">{post.date}</p>
                    <h2 className="text-2xl font-bold mt-1">{post.title}</h2>
                  </div>
                  <p className="text-muted-foreground">{post.excerpt}</p>
                </div>
                <div className="mt-4">
                  <Link href={`/blog/${post.slug}`}>
                    <Button variant="outline">Read More</Button>
                  </Link>
                </div>
              </CardContent>
            </div>
          </Card>
        ))}
      </div>

      <div className="flex justify-center mt-12">
        <Button variant="outline">Load More Posts</Button>
      </div>
    </div>
  )
}

const blogPosts = [
  {
    title: "Finding Inspiration in Everyday Life",
    slug: "finding-inspiration",
    date: "May 15, 2023",
    excerpt:
      "How the mundane moments often lead to the most extraordinary stories. In this post, I share my process for turning everyday observations into compelling narrative.",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "My Writing Process Revealed",
    slug: "writing-process",
    date: "April 22, 2023",
    excerpt:
      "A behind-the-scenes look at how I craft my novels from concept to completion. From initial idea to final manuscript, here's how my books come to life.",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "Navigating the Publishing World",
    slug: "navigating-publishing",
    date: "March 10, 2023",
    excerpt:
      "Tips and insights for new authors looking to break into traditional publishing. What I wish I'd known when I started my journey as a published author.",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "The Art of Character Development",
    slug: "character-development",
    date: "February 5, 2023",
    excerpt:
      "Creating characters that leap off the page and into readers' hearts. Learn my techniques for developing complex, believable characters that drive your story.",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "Writing Through Writer's Block",
    slug: "writers-block",
    date: "January 18, 2023",
    excerpt:
      "Strategies I use when the words won't come. Everyone faces creative blocks—here's how I've learned to overcome them and keep the story moving forward.",
    image: "/placeholder.svg?height=400&width=600",
  },
]
