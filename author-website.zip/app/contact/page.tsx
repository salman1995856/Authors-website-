"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Mail, MapPin, Phone } from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubmitted(true)
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: "",
      })
    }, 1500)
  }

  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="flex flex-col items-center justify-center space-y-4 text-center">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Contact Me</h1>
          <p className="max-w-[700px] text-muted-foreground md:text-xl">
            I'd love to hear from you. Get in touch for inquiries, events, or just to say hello.
          </p>
        </div>
      </div>

      <div className="grid gap-12 mt-12 md:grid-cols-2">
        <div className="space-y-8">
          <div>
            <h2 className="text-2xl font-bold">Get in Touch</h2>
            <p className="mt-2 text-muted-foreground">
              Fill out the form and I'll get back to you as soon as possible.
            </p>
          </div>

          <div className="flex items-start space-x-4">
            <Mail className="h-6 w-6 mt-1 text-muted-foreground" />
            <div>
              <h3 className="font-medium">Email</h3>
              <p className="text-muted-foreground">contact@janeausten.com</p>
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <MapPin className="h-6 w-6 mt-1 text-muted-foreground" />
            <div>
              <h3 className="font-medium">Literary Agent</h3>
              <p className="text-muted-foreground">
                Sarah Johnson
                <br />
                Johnson Literary Agency
                <br />
                123 Book Lane
                <br />
                New York, NY 10001
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <Phone className="h-6 w-6 mt-1 text-muted-foreground" />
            <div>
              <h3 className="font-medium">Publicity</h3>
              <p className="text-muted-foreground">
                For media inquiries, please contact:
                <br />
                Michael Smith
                <br />
                publicity@janeausten.com
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {isSubmitted ? (
            <div className="rounded-lg border p-8 text-center">
              <h3 className="text-2xl font-bold">Thank You!</h3>
              <p className="mt-2 text-muted-foreground">
                Your message has been received. I'll get back to you as soon as possible.
              </p>
              <Button className="mt-4" onClick={() => setIsSubmitted(false)}>
                Send Another Message
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Input id="subject" name="subject" value={formData.subject} onChange={handleChange} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  name="message"
                  rows={5}
                  value={formData.message}
                  onChange={handleChange}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Sending..." : "Send Message"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
