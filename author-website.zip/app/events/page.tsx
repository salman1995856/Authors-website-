import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, MapPin } from "lucide-react"

export default function EventsPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="flex flex-col items-center justify-center space-y-4 text-center">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Upcoming Events</h1>
          <p className="max-w-[700px] text-muted-foreground md:text-xl">Book signings, readings, and appearances</p>
        </div>
      </div>

      <div className="grid gap-6 mt-12">
        {events.map((event, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="grid gap-4 md:grid-cols-[1fr_auto]">
                <div className="space-y-3">
                  <h2 className="text-2xl font-bold">{event.title}</h2>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>
                      {event.date} • {event.time}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{event.location}</span>
                  </div>
                  <p className="text-muted-foreground">{event.description}</p>
                </div>
                <div className="flex items-center">
                  <Link href={event.ticketLink}>
                    <Button variant={event.soldOut ? "outline" : "default"} disabled={event.soldOut}>
                      {event.soldOut ? "Sold Out" : "Get Tickets"}
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-16">
        <h2 className="text-2xl font-bold text-center">Past Events</h2>
        <div className="grid gap-6 mt-8">
          {pastEvents.map((event, index) => (
            <Card key={index} className="bg-muted/50">
              <CardContent className="p-6">
                <div className="grid gap-4 md:grid-cols-[1fr_auto]">
                  <div className="space-y-3">
                    <h2 className="text-xl font-bold">{event.title}</h2>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{event.location}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold">Book a Speaking Engagement</h2>
        <p className="mt-2 text-muted-foreground max-w-2xl mx-auto">
          I'm available for select speaking engagements, book club appearances, and literary festivals. Please contact
          my agent for details and availability.
        </p>
        <Link href="/contact">
          <Button className="mt-6">Contact for Bookings</Button>
        </Link>
      </div>
    </div>
  )
}

const events = [
  {
    title: "Book Launch: The Silent Echo",
    date: "June 15, 2023",
    time: "7:00 PM",
    location: "Powell's Books, Portland, OR",
    description:
      "Join me for the official launch of my newest novel, The Silent Echo. I'll be reading selected passages, answering questions, and signing copies.",
    ticketLink: "/events/book-launch",
    soldOut: false,
  },
  {
    title: "Literary Festival Panel: The Future of Fiction",
    date: "July 8, 2023",
    time: "2:30 PM",
    location: "Bay Area Book Festival, Berkeley, CA",
    description:
      "I'll be joining a panel of acclaimed authors to discuss emerging trends in contemporary fiction and what the future holds for storytelling.",
    ticketLink: "/events/literary-festival",
    soldOut: false,
  },
  {
    title: "Author Talk & Signing",
    date: "July 22, 2023",
    time: "6:00 PM",
    location: "The Strand Bookstore, New York, NY",
    description:
      "An evening of conversation about my writing journey, creative process, and the themes that inspire my work. Followed by a book signing.",
    ticketLink: "/events/author-talk",
    soldOut: true,
  },
  {
    title: "Writing Workshop: Crafting Compelling Characters",
    date: "August 5, 2023",
    time: "10:00 AM - 3:00 PM",
    location: "Seattle Public Library, Seattle, WA",
    description:
      "A hands-on workshop where I'll share techniques for developing memorable characters that drive your narrative. Limited to 25 participants.",
    ticketLink: "/events/writing-workshop",
    soldOut: false,
  },
]

const pastEvents = [
  {
    title: "Beyond the Horizon Book Tour",
    date: "November 10, 2022",
    location: "Elliott Bay Book Company, Seattle, WA",
  },
  {
    title: "Literary Salon: The Art of the Novel",
    date: "October 5, 2022",
    location: "City Lights Bookstore, San Francisco, CA",
  },
  {
    title: "Summer Reading Series",
    date: "July 15, 2022",
    location: "Bryant Park, New York, NY",
  },
]
