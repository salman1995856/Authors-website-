import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="flex flex-col items-center justify-center space-y-4 text-center">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About Jane Austen</h1>
          <p className="max-w-[700px] text-muted-foreground md:text-xl">Award-winning author of contemporary fiction</p>
        </div>
      </div>

      <div className="grid gap-12 mt-12 md:grid-cols-2 items-start">
        <div className="relative h-[400px] w-full md:h-[600px]">
          <Image
            src="/placeholder.svg?height=600&width=500"
            alt="Jane Austen portrait"
            fill
            className="object-cover rounded-lg"
          />
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold">My Story</h2>
            <div className="mt-4 space-y-4">
              <p>
                I've been writing stories since I was a child, captivated by the power of words to transport readers to
                new worlds. My journey as an author began fifteen years ago with my debut novel "Whispers in the Wind,"
                which unexpectedly became a national bestseller.
              </p>
              <p>
                Since then, I've published twelve novels, each exploring the complexities of human relationships and the
                resilience of the human spirit. My work has been translated into twenty-three languages and adapted for
                both stage and screen.
              </p>
              <p>
                Born and raised in a small coastal town, I draw inspiration from the natural world and the fascinating
                people I've met throughout my life. When I'm not writing, you can find me hiking along the shoreline,
                tending to my garden, or lost in the pages of a good book.
              </p>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold">Awards & Recognition</h2>
            <ul className="mt-4 space-y-2">
              <li>National Book Award Finalist (2022)</li>
              <li>Pulitzer Prize for Fiction (2019)</li>
              <li>PEN/Faulkner Award (2017)</li>
              <li>Costa Book Award (2015)</li>
              <li>Women's Prize for Fiction (2012)</li>
            </ul>
          </div>

          <div>
            <h2 className="text-2xl font-bold">My Writing Process</h2>
            <p className="mt-4">
              I begin each day at 5 AM, writing for three hours before the rest of the world wakes up. My first drafts
              are always handwritten—there's something about the connection between pen and paper that sparks my
              creativity in ways a keyboard cannot. I typically spend six months researching, six months writing, and
              another six months revising before a book is ready for my editor's eyes.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-16">
        <h2 className="text-2xl font-bold text-center">Frequently Asked Questions</h2>
        <div className="grid gap-6 mt-8 md:grid-cols-2">
          <div className="space-y-2">
            <h3 className="text-xl font-semibold">Where do you get your ideas?</h3>
            <p className="text-muted-foreground">
              Ideas come from everywhere—overheard conversations, newspaper articles, dreams, and the eternal question:
              "What if?" I keep a notebook with me at all times to capture these sparks before they fade.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-semibold">Do you base characters on real people?</h3>
            <p className="text-muted-foreground">
              My characters are mosaics—tiny pieces collected from people I've known, observed, or imagined, assembled
              into someone entirely new. No single character is ever based on just one person.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-semibold">What advice do you have for aspiring writers?</h3>
            <p className="text-muted-foreground">
              Read voraciously. Write regularly. Finish what you start. Learn to accept and apply criticism. And perhaps
              most importantly, be patient with yourself—mastery takes time.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-semibold">Will you read my manuscript?</h3>
            <p className="text-muted-foreground">
              Unfortunately, my schedule and legal considerations prevent me from reading unpublished manuscripts. I
              recommend finding a reputable literary agent who can guide your work to publication.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
