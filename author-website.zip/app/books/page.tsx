import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function BooksPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="flex flex-col items-center justify-center space-y-4 text-center">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">My Books</h1>
          <p className="max-w-[700px] text-muted-foreground md:text-xl">
            Explore my complete collection of published works
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
        {allBooks.map((book, index) => (
          <Card key={index} className="overflow-hidden">
            <div className="aspect-[2/3] relative">
              <Image
                src={book.cover || "/placeholder.svg"}
                alt={book.title}
                fill
                className="object-cover transition-all hover:scale-105"
              />
            </div>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold">{book.title}</h3>
              <p className="text-sm text-muted-foreground mt-2">{book.year}</p>
              <p className="mt-2 text-muted-foreground">{book.description}</p>
              <div className="flex justify-between items-center mt-4">
                <span className="font-medium">{book.price}</span>
                <Link href={`/books/${book.slug}`}>
                  <Button variant="outline" size="sm">
                    Read More
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

const allBooks = [
  {
    title: "The Silent Echo",
    slug: "the-silent-echo",
    year: "2023",
    description: "A haunting tale of loss and redemption set in a small coastal town.",
    price: "$18.99",
    cover: "/placeholder.svg?height=450&width=300",
  },
  {
    title: "Beyond the Horizon",
    slug: "beyond-the-horizon",
    year: "2021",
    description: "An epic journey across continents in search of a long-lost family secret.",
    price: "$21.99",
    cover: "/placeholder.svg?height=450&width=300",
  },
  {
    title: "Whispers in the Wind",
    slug: "whispers-in-the-wind",
    year: "2019",
    description: "The debut novel that captivated readers worldwide with its lyrical prose.",
    price: "$16.99",
    cover: "/placeholder.svg?height=450&width=300",
  },
  {
    title: "The Forgotten Garden",
    slug: "the-forgotten-garden",
    year: "2018",
    description: "A mysterious garden holds the key to a family's dark past.",
    price: "$19.99",
    cover: "/placeholder.svg?height=450&width=300",
  },
  {
    title: "Shadows of Yesterday",
    slug: "shadows-of-yesterday",
    year: "2016",
    description: "When the past refuses to stay buried, one woman must confront her darkest fears.",
    price: "$17.99",
    cover: "/placeholder.svg?height=450&width=300",
  },
  {
    title: "The Last Letter",
    slug: "the-last-letter",
    year: "2014",
    description: "A letter arrives twenty years too late, changing everything for its recipient.",
    price: "$15.99",
    cover: "/placeholder.svg?height=450&width=300",
  },
]
